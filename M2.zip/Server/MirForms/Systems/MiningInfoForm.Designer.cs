﻿namespace Server
{
    partial class MiningInfoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label79 = new System.Windows.Forms.Label();
            this.MineNametextBox = new System.Windows.Forms.TextBox();
            this.MineSlotstextBox = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.MineDropRatetextBox = new System.Windows.Forms.TextBox();
            this.MineHitRatetextBox = new System.Windows.Forms.TextBox();
            this.MineAttemptstextBox = new System.Windows.Forms.TextBox();
            this.MineRegenDelaytextBox = new System.Windows.Forms.TextBox();
            this.label67 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label78 = new System.Windows.Forms.Label();
            this.MineDropsIndexcomboBox = new System.Windows.Forms.ComboBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.MineMaxBonustextBox = new System.Windows.Forms.TextBox();
            this.label77 = new System.Windows.Forms.Label();
            this.MineBonusChancetextBox = new System.Windows.Forms.TextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.MineMaxQualitytextBox = new System.Windows.Forms.TextBox();
            this.label75 = new System.Windows.Forms.Label();
            this.MineMinQualitytextBox = new System.Windows.Forms.TextBox();
            this.label74 = new System.Windows.Forms.Label();
            this.MineMaxSlottextBox = new System.Windows.Forms.TextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.MineMinSlottextBox = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.MineItemNametextBox = new System.Windows.Forms.TextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.MineRemoveDropbutton = new System.Windows.Forms.Button();
            this.MineAddDropbutton = new System.Windows.Forms.Button();
            this.MineRemoveIndexbutton = new System.Windows.Forms.Button();
            this.MineAddIndexbutton = new System.Windows.Forms.Button();
            this.MineIndexcomboBox = new System.Windows.Forms.ComboBox();
            this.label64 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 33);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(427, 263);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox7);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(419, 237);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Stats";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label79);
            this.groupBox7.Controls.Add(this.MineNametextBox);
            this.groupBox7.Controls.Add(this.MineSlotstextBox);
            this.groupBox7.Controls.Add(this.label70);
            this.groupBox7.Controls.Add(this.label69);
            this.groupBox7.Controls.Add(this.label68);
            this.groupBox7.Controls.Add(this.MineDropRatetextBox);
            this.groupBox7.Controls.Add(this.MineHitRatetextBox);
            this.groupBox7.Controls.Add(this.MineAttemptstextBox);
            this.groupBox7.Controls.Add(this.MineRegenDelaytextBox);
            this.groupBox7.Controls.Add(this.label67);
            this.groupBox7.Controls.Add(this.label66);
            this.groupBox7.Controls.Add(this.label65);
            this.groupBox7.Location = new System.Drawing.Point(10, 6);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(403, 121);
            this.groupBox7.TabIndex = 27;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Mine Base Stat";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(8, 19);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(38, 13);
            this.label79.TabIndex = 23;
            this.label79.Text = "Name:";
            // 
            // MineNametextBox
            // 
            this.MineNametextBox.Location = new System.Drawing.Point(97, 16);
            this.MineNametextBox.Name = "MineNametextBox";
            this.MineNametextBox.Size = new System.Drawing.Size(100, 20);
            this.MineNametextBox.TabIndex = 22;
            this.MineNametextBox.TextChanged += new System.EventHandler(this.MineNametextBox_TextChanged);
            // 
            // MineSlotstextBox
            // 
            this.MineSlotstextBox.Location = new System.Drawing.Point(97, 92);
            this.MineSlotstextBox.Name = "MineSlotstextBox";
            this.MineSlotstextBox.Size = new System.Drawing.Size(34, 20);
            this.MineSlotstextBox.TabIndex = 10;
            this.MineSlotstextBox.TextChanged += new System.EventHandler(this.MineSlotstextBox_TextChanged);
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(6, 95);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(33, 13);
            this.label70.TabIndex = 9;
            this.label70.Text = "Slots:";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(286, 45);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(56, 13);
            this.label69.TabIndex = 8;
            this.label69.Text = "DropRate:";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(286, 19);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(46, 13);
            this.label68.TabIndex = 7;
            this.label68.Text = "HitRate:";
            // 
            // MineDropRatetextBox
            // 
            this.MineDropRatetextBox.Location = new System.Drawing.Point(362, 42);
            this.MineDropRatetextBox.Name = "MineDropRatetextBox";
            this.MineDropRatetextBox.Size = new System.Drawing.Size(34, 20);
            this.MineDropRatetextBox.TabIndex = 6;
            this.MineDropRatetextBox.TextChanged += new System.EventHandler(this.MineDropRatetextBox_TextChanged);
            // 
            // MineHitRatetextBox
            // 
            this.MineHitRatetextBox.Location = new System.Drawing.Point(362, 16);
            this.MineHitRatetextBox.Name = "MineHitRatetextBox";
            this.MineHitRatetextBox.Size = new System.Drawing.Size(34, 20);
            this.MineHitRatetextBox.TabIndex = 5;
            this.MineHitRatetextBox.TextChanged += new System.EventHandler(this.MineHitRatetextBox_TextChanged);
            // 
            // MineAttemptstextBox
            // 
            this.MineAttemptstextBox.Location = new System.Drawing.Point(97, 68);
            this.MineAttemptstextBox.Name = "MineAttemptstextBox";
            this.MineAttemptstextBox.Size = new System.Drawing.Size(34, 20);
            this.MineAttemptstextBox.TabIndex = 4;
            this.MineAttemptstextBox.TextChanged += new System.EventHandler(this.MineAttemptstextBox_TextChanged);
            // 
            // MineRegenDelaytextBox
            // 
            this.MineRegenDelaytextBox.Location = new System.Drawing.Point(97, 42);
            this.MineRegenDelaytextBox.Name = "MineRegenDelaytextBox";
            this.MineRegenDelaytextBox.Size = new System.Drawing.Size(34, 20);
            this.MineRegenDelaytextBox.TabIndex = 3;
            this.MineRegenDelaytextBox.TextChanged += new System.EventHandler(this.MineRegenDelaytextBox_TextChanged);
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(8, 71);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(83, 13);
            this.label67.TabIndex = 2;
            this.label67.Text = "Attempts/regen:";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(148, 45);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(49, 13);
            this.label66.TabIndex = 1;
            this.label66.Text = "(minutes)";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(8, 45);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(70, 13);
            this.label65.TabIndex = 0;
            this.label65.Text = "Regen delay:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label78);
            this.tabPage2.Controls.Add(this.MineDropsIndexcomboBox);
            this.tabPage2.Controls.Add(this.groupBox8);
            this.tabPage2.Controls.Add(this.MineRemoveDropbutton);
            this.tabPage2.Controls.Add(this.MineAddDropbutton);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(419, 237);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Drops";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(7, 40);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(38, 13);
            this.label78.TabIndex = 26;
            this.label78.Text = "Drops:";
            // 
            // MineDropsIndexcomboBox
            // 
            this.MineDropsIndexcomboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.MineDropsIndexcomboBox.FormattingEnabled = true;
            this.MineDropsIndexcomboBox.Location = new System.Drawing.Point(12, 12);
            this.MineDropsIndexcomboBox.Name = "MineDropsIndexcomboBox";
            this.MineDropsIndexcomboBox.Size = new System.Drawing.Size(129, 21);
            this.MineDropsIndexcomboBox.TabIndex = 22;
            this.MineDropsIndexcomboBox.SelectedIndexChanged += new System.EventHandler(this.MineDropsIndexcomboBox_SelectedIndexChanged);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.MineMaxBonustextBox);
            this.groupBox8.Controls.Add(this.label77);
            this.groupBox8.Controls.Add(this.MineBonusChancetextBox);
            this.groupBox8.Controls.Add(this.label76);
            this.groupBox8.Controls.Add(this.MineMaxQualitytextBox);
            this.groupBox8.Controls.Add(this.label75);
            this.groupBox8.Controls.Add(this.MineMinQualitytextBox);
            this.groupBox8.Controls.Add(this.label74);
            this.groupBox8.Controls.Add(this.MineMaxSlottextBox);
            this.groupBox8.Controls.Add(this.label73);
            this.groupBox8.Controls.Add(this.MineMinSlottextBox);
            this.groupBox8.Controls.Add(this.label72);
            this.groupBox8.Controls.Add(this.MineItemNametextBox);
            this.groupBox8.Controls.Add(this.label71);
            this.groupBox8.Location = new System.Drawing.Point(10, 39);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(188, 188);
            this.groupBox8.TabIndex = 25;
            this.groupBox8.TabStop = false;
            // 
            // MineMaxBonustextBox
            // 
            this.MineMaxBonustextBox.Location = new System.Drawing.Point(99, 151);
            this.MineMaxBonustextBox.Name = "MineMaxBonustextBox";
            this.MineMaxBonustextBox.Size = new System.Drawing.Size(34, 20);
            this.MineMaxBonustextBox.TabIndex = 34;
            this.MineMaxBonustextBox.TextChanged += new System.EventHandler(this.MineMaxBonustextBox_TextChanged);
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(10, 154);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(84, 13);
            this.label77.TabIndex = 33;
            this.label77.Text = "Maximum Bonus";
            // 
            // MineBonusChancetextBox
            // 
            this.MineBonusChancetextBox.Location = new System.Drawing.Point(99, 127);
            this.MineBonusChancetextBox.Name = "MineBonusChancetextBox";
            this.MineBonusChancetextBox.Size = new System.Drawing.Size(34, 20);
            this.MineBonusChancetextBox.TabIndex = 32;
            this.MineBonusChancetextBox.TextChanged += new System.EventHandler(this.MineBonusChancetextBox_TextChanged);
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(10, 130);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(77, 13);
            this.label76.TabIndex = 31;
            this.label76.Text = "Bonus Chance";
            // 
            // MineMaxQualitytextBox
            // 
            this.MineMaxQualitytextBox.Location = new System.Drawing.Point(99, 104);
            this.MineMaxQualitytextBox.Name = "MineMaxQualitytextBox";
            this.MineMaxQualitytextBox.Size = new System.Drawing.Size(34, 20);
            this.MineMaxQualitytextBox.TabIndex = 30;
            this.MineMaxQualitytextBox.TextChanged += new System.EventHandler(this.MineMaxQualitytextBox_TextChanged);
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(10, 107);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(86, 13);
            this.label75.TabIndex = 29;
            this.label75.Text = "Maximum Quality";
            // 
            // MineMinQualitytextBox
            // 
            this.MineMinQualitytextBox.Location = new System.Drawing.Point(99, 81);
            this.MineMinQualitytextBox.Name = "MineMinQualitytextBox";
            this.MineMinQualitytextBox.Size = new System.Drawing.Size(34, 20);
            this.MineMinQualitytextBox.TabIndex = 28;
            this.MineMinQualitytextBox.TextChanged += new System.EventHandler(this.MineMinQualitytextBox_TextChanged);
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(10, 84);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(83, 13);
            this.label74.TabIndex = 27;
            this.label74.Text = "Minimum Quality";
            // 
            // MineMaxSlottextBox
            // 
            this.MineMaxSlottextBox.Location = new System.Drawing.Point(99, 59);
            this.MineMaxSlottextBox.Name = "MineMaxSlottextBox";
            this.MineMaxSlottextBox.Size = new System.Drawing.Size(34, 20);
            this.MineMaxSlottextBox.TabIndex = 26;
            this.MineMaxSlottextBox.TextChanged += new System.EventHandler(this.MineMaxSlottextBox_TextChanged);
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(10, 62);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(51, 13);
            this.label73.TabIndex = 25;
            this.label73.Text = "Max Slot:";
            // 
            // MineMinSlottextBox
            // 
            this.MineMinSlottextBox.Location = new System.Drawing.Point(99, 36);
            this.MineMinSlottextBox.Name = "MineMinSlottextBox";
            this.MineMinSlottextBox.Size = new System.Drawing.Size(34, 20);
            this.MineMinSlottextBox.TabIndex = 24;
            this.MineMinSlottextBox.TextChanged += new System.EventHandler(this.MineMinSlottextBox_TextChanged);
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(10, 39);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(48, 13);
            this.label72.TabIndex = 23;
            this.label72.Text = "Min Slot:";
            // 
            // MineItemNametextBox
            // 
            this.MineItemNametextBox.Location = new System.Drawing.Point(99, 13);
            this.MineItemNametextBox.Name = "MineItemNametextBox";
            this.MineItemNametextBox.Size = new System.Drawing.Size(83, 20);
            this.MineItemNametextBox.TabIndex = 22;
            this.MineItemNametextBox.TextChanged += new System.EventHandler(this.MineItemNametextBox_TextChanged);
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(10, 16);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(58, 13);
            this.label71.TabIndex = 21;
            this.label71.Text = "ItemName:";
            // 
            // MineRemoveDropbutton
            // 
            this.MineRemoveDropbutton.Location = new System.Drawing.Point(177, 12);
            this.MineRemoveDropbutton.Name = "MineRemoveDropbutton";
            this.MineRemoveDropbutton.Size = new System.Drawing.Size(21, 21);
            this.MineRemoveDropbutton.TabIndex = 24;
            this.MineRemoveDropbutton.Text = "-";
            this.MineRemoveDropbutton.UseVisualStyleBackColor = true;
            this.MineRemoveDropbutton.Click += new System.EventHandler(this.MineRemoveDropbutton_Click);
            // 
            // MineAddDropbutton
            // 
            this.MineAddDropbutton.Location = new System.Drawing.Point(148, 12);
            this.MineAddDropbutton.Name = "MineAddDropbutton";
            this.MineAddDropbutton.Size = new System.Drawing.Size(21, 21);
            this.MineAddDropbutton.TabIndex = 23;
            this.MineAddDropbutton.Text = "+";
            this.MineAddDropbutton.UseVisualStyleBackColor = true;
            this.MineAddDropbutton.Click += new System.EventHandler(this.MineAddDropbutton_Click);
            // 
            // MineRemoveIndexbutton
            // 
            this.MineRemoveIndexbutton.Location = new System.Drawing.Point(218, 6);
            this.MineRemoveIndexbutton.Name = "MineRemoveIndexbutton";
            this.MineRemoveIndexbutton.Size = new System.Drawing.Size(21, 21);
            this.MineRemoveIndexbutton.TabIndex = 26;
            this.MineRemoveIndexbutton.Text = "-";
            this.MineRemoveIndexbutton.UseVisualStyleBackColor = true;
            this.MineRemoveIndexbutton.Click += new System.EventHandler(this.MineRemoveIndexbutton_Click);
            // 
            // MineAddIndexbutton
            // 
            this.MineAddIndexbutton.Location = new System.Drawing.Point(189, 6);
            this.MineAddIndexbutton.Name = "MineAddIndexbutton";
            this.MineAddIndexbutton.Size = new System.Drawing.Size(21, 21);
            this.MineAddIndexbutton.TabIndex = 25;
            this.MineAddIndexbutton.Text = "+";
            this.MineAddIndexbutton.UseVisualStyleBackColor = true;
            this.MineAddIndexbutton.Click += new System.EventHandler(this.MineAddIndexbutton_Click);
            // 
            // MineIndexcomboBox
            // 
            this.MineIndexcomboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.MineIndexcomboBox.FormattingEnabled = true;
            this.MineIndexcomboBox.Location = new System.Drawing.Point(91, 6);
            this.MineIndexcomboBox.Name = "MineIndexcomboBox";
            this.MineIndexcomboBox.Size = new System.Drawing.Size(92, 21);
            this.MineIndexcomboBox.TabIndex = 23;
            this.MineIndexcomboBox.SelectedIndexChanged += new System.EventHandler(this.MineIndexcomboBox_SelectedIndexChanged);
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(13, 9);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(62, 13);
            this.label64.TabIndex = 24;
            this.label64.Text = "Mine Index:";
            // 
            // MiningInfoForm
            // 
            this.ClientSize = new System.Drawing.Size(450, 305);
            this.Controls.Add(this.MineRemoveIndexbutton);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.MineAddIndexbutton);
            this.Controls.Add(this.label64);
            this.Controls.Add(this.MineIndexcomboBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MiningInfoForm";
            this.Text = "MiningInfoForm";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MiningInfoForm_FormClosed);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button MineRemoveIndexbutton;
        private System.Windows.Forms.Button MineAddIndexbutton;
        private System.Windows.Forms.ComboBox MineIndexcomboBox;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.TextBox MineNametextBox;
        private System.Windows.Forms.TextBox MineSlotstextBox;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.TextBox MineDropRatetextBox;
        private System.Windows.Forms.TextBox MineHitRatetextBox;
        private System.Windows.Forms.TextBox MineAttemptstextBox;
        private System.Windows.Forms.TextBox MineRegenDelaytextBox;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.ComboBox MineDropsIndexcomboBox;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox MineMaxBonustextBox;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.TextBox MineBonusChancetextBox;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.TextBox MineMaxQualitytextBox;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.TextBox MineMinQualitytextBox;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.TextBox MineMaxSlottextBox;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.TextBox MineMinSlottextBox;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.TextBox MineItemNametextBox;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Button MineRemoveDropbutton;
        private System.Windows.Forms.Button MineAddDropbutton;
    }
}