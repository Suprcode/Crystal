# Legend of Mir 2

Visit our forum at [LOMCN](http://www.lomcn.org/forum/forumdisplay.php?633) for discussions, help, and updates.

## Wiki

For in depth guides and tutorials about the files visit our [Wiki](http://mir2wiki.com)
